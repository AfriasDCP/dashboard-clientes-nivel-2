import { Component } from '@angular/core';
import { TableRowCollapseEvent, TableRowExpandEvent } from 'primeng/table';
import { DispositivosService } from './services/dispositivos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  title = 'nivel-2';
  expandedRows = {};
  products = [];

  dispositivos: any[] = [];

  constructor(private dispositivosService: DispositivosService) {}

  ngOnInit(): void {
    const params = this.getParentUrlParams();
    this.cargarDispositivos(params);
  }

  getParentUrlParams(): any {
    // const parentUrl = window.parent.location.href;
    const parentUrl = 'http://10.71.35.121:3000/d/dce64370-7513-4776-bfa6-7df7cc7026b9/849f9cad-8a58-50cf-8625-b6e8ddba3496?orgId=1&var-Cliente=ADMINISTRACION%20PORTUARIA%20INTEGRAL&var-Puntas=All&var-Afectadas=0&var-Hoy=0';
    const urlParams = new URLSearchParams(new URL(parentUrl).search);

    const params = {
      cliente: urlParams.get('var-Cliente') || '',
      puntas: urlParams.get('var-Puntas') || '',
      afectadas: urlParams.get('var-Afectadas') || '0',
      hoy: urlParams.get('var-Hoy') || '0',
    };

    return params;
  }

  cargarDispositivos(params: any): void {
    this.dispositivosService.obtenerDispositivos(params).subscribe((data) => {
      this.dispositivos = data;
    });
  }

  expandAll() {
    // this.expandedRows = this.products.reduce((acc, p) => (acc[p.id] = true) && acc, {});
  }

  collapseAll() {
    // this.expandedRows = {};
  }

  onRowExpand(event: TableRowExpandEvent) {
    // this.messageService.add({ severity: 'info', summary: 'Product Expanded', detail: event.data.name, life: 3000 });
  }

  onRowCollapse(event: TableRowCollapseEvent) {
    // this.messageService.add({ severity: 'success', summary: 'Product Collapsed', detail: event.data.name, life: 3000 });
  }
}
